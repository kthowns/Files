package com.example.a1010;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText numPr,numSe;
    Button[] numBtn = new Button[10];
    Button btnSum,btnSub,btnMul,btnDiv;
    Integer[] btnID = { R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5,
            R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9 };
    TextView txtResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("테이블레이아웃 계산기");
        numPr = findViewById(R.id.numPr);
        numSe = findViewById(R.id.numSe);
        btnSum = findViewById(R.id.btnSum);
        btnSub = findViewById(R.id.btnSub);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);
        txtResult = findViewById(R.id.txtResult);
        for(int i=0; i<btnID.length; i++){
            numBtn[i] = findViewById(btnID[i]);
        }
        btnSum.setOnClickListener(view->{
            calc(txtResult, 0);
        });
        btnSub.setOnClickListener(view->{
            calc(txtResult,1);
        });
        btnMul.setOnClickListener(view->{
            calc(txtResult,2);
        });
        btnDiv.setOnClickListener(view->{
            calc(txtResult,3);
        });
        for(int i=0; i<btnID.length; i++){
            final int index = i;

            numBtn[index].setOnClickListener(view->{
                if(numPr.isFocused()==true) {
                    String btnTxt = numBtn[index].getText().toString();
                        numPr.setText(numPr.getText().toString() + btnTxt);
                }else if(numSe.isFocused()==true){
                    String btnTxt = numBtn[index].getText().toString();
                    numSe.setText(numSe.getText().toString()+btnTxt);
                }
            });
        }
    }
    void calc(TextView result, int type){
        String strResult;
        double pr = Integer.parseInt(numPr.getText().toString());
        double se = Integer.parseInt(numSe.getText().toString());
        switch(type){
            case 0:
                strResult = "계산 결과 : "+(pr+se);
                break;
            case 1:
                strResult = "계산 결과 : "+(pr-se);
                break;
            case 2:
                strResult = "계산 결과 : "+(pr*se);
                break;
            default:
                strResult = "계산 결과 : "+(pr/se);
        }
        result.setText(strResult);
    }
}